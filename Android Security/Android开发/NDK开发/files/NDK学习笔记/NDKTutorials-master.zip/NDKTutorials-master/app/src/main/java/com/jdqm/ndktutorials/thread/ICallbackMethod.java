package com.jdqm.ndktutorials.thread;

public interface ICallbackMethod {
    void callback();
}
