package com.jdqm.ndktutorials.thread;

public interface IThreadCallback {
    void callback();
}
