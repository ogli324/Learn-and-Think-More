#include "options.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//#define _GNU_SOURCE		/* 为了支持getopt_long */
#include <getopt.h>


// 打印软件版本以及提示信息
void usage() {

	printf("udog [options] file\n");
	printf("http://www.nagapt.com\n");
	show_version();
}

void show_version() {

	printf("V%s\n", UDOG_VERSION_STRING);
}

// 使用帮助的命令行参数
void show_help() {

	printf("\t----------------------------------------\n");
	printf("\t|==== Android Native Lib Cracker ====  |\n");
	printf("\t----------------------------------------\n");
	printf("udog [options] file\n");
	printf("-d, --dump=file                     dump load so to file\n");
	printf("--clear-entry                       clear DT_INIT value\n");
	printf("-c, --check                         print code sign\n");
	printf("--xcto=offset(hex)                  set xct offset\n");
	printf("--xcts=size(hex)                    set xct size\n");
	printf("-h, --help                          show help\n");
	printf("-v, --version                       show version\n");
	printf("--debug=level                       show debug information\n");
	printf("http://www.nagapt.com\n");
	show_version();
	printf("\n");
}


// 解析用户输入的命令行参数
struct options_t* handle_arguments(int argc, char* argv[]) {

	// 保存命令行参数解析后的结果
	static struct options_t opts;
	// 清零
	memset(&opts, 0, sizeof(opts));
	// 默认参数的设置
	opts.call_dt_init = true;
	opts.call_dt_init_array = true;
	opts.call_dt_finit = true;
	opts.call_dt_finit_array = true;
	opts.load_pre_libs = true;
	opts.load_needed_libs = true;

	int opt;
	int longidx;
	int dump = 0, help = 0, version = 0,
		debug = 0, check = 0, xcto = 0,
		xcts = 0, clear_entry = 0;

	if (argc == 1) {
		return NULL;
	}

	// 输入参数选项的解析顺序和规则
	// 该数据结构包括了所有要定义的短选项，每一个选项都只用单个字母表示。
	// 如果该选项需要参数，则其后跟一个冒号
	const char* short_opts = ":hvcd:";
	// 解析参数的长选项
	struct option long_opts[] = {
		// 1--选项需要参数
	 	{ "dump", 1, &dump, 1 },
		// 0--选项无参数
		{ "help", 0, &help, 2 },
		{ "version", 0, &version, 3 },
		{ "debug", 1, &debug, 4 },
		{ "check", 0, &check, 5 },
		{ "xcto", 1, &xcto, 6 },
		{ "xcts", 1, &xcts, 7 },
		{ "clear-entry",0, &clear_entry, 8 },
		// 2--选项参数可选
	 	{ 0, 0, 0, 0 }
	};

	// 对输入的命令行参数进行解析,longidx为解析参数长选项中的序号数
	// 参考:https://baike.baidu.com/item/getopt_long/5634851?fr=aladdin
	// 参考:http://blog.csdn.net/ast_224/article/details/3861625
	while ((opt = getopt_long(argc, argv, short_opts, long_opts, &longidx)) != -1) {

		switch (opt) {
		case 0:
			// 进行so库文件的dump处理
			if (dump == 1) {

				opts.dump = true;
				// 暂时不对dump的so库文件的重定位表进行修复
				opts.not_relocal = false;
				// 对dump的so库文件的区节头表进行重建
				opts.make_sectabs = true;

				// 当处理一个带参数的选项时，全局变量optarg会指向它的参数
				// optarg为目标so库文件dump后的文件保存路径
				strcpy(opts.dump_file, optarg);
				// 加载dump的so库文件
				opts.load = true;
				dump = 0;

			} else if (help == 2) {

				opts.help = true;
				help = 0;

			} else if (version == 3) {

				opts.version = true;
				version = 0;

			} else if (debug == 4) {

				opts.debug = true;
				opts.debuglevel = atoi(optarg);
				debug = 0;

			} else if (check == 5) {

				opts.check = true;
				check = 0;

			} else if (xcto == 6) {

				opts.xct_offset = strtol(optarg, NULL, 16);
				xcto = 0;

			} else if (xcts == 7) {

				opts.xct_size = strtol(optarg, NULL, 16);
				xcts = 0;

			} else if (clear_entry == 8) {

				opts.clear_entry = true;
				clear_entry = 0;

			} else {

				//printf("unknow options: %c\n", optopt);
				return NULL;
			}
			break;
		case 'c':
			opts.check = true;
			break;
		case 'h':
			opts.help = true;
			break;
		case 'v':
			opts.version = true;
			break;
		case 'd':
			opts.dump = true;
			opts.not_relocal = false;
			opts.make_sectabs = true;
			strcpy(opts.dump_file, optarg);
			opts.load = true;
			break;
		case '?':
			//printf("unknow options: %c\n", optopt);
			return NULL;
			break;
		case ':':
			//printf("option need a option\n");
			return NULL;
			break;
		}/* end switch */
	}/* end while */


	/* 无文件 */
	if (optind == argc) {
		return NULL;
	}

	// 当函数分析完所有参数时，全局变量optind（into argv）会指向第一个‘非选项’的位置
	// 需要被dump的so库文件的文件路径
	strcpy(opts.target_file, argv[optind]);

	// 返回的引用
	return &opts;
}



