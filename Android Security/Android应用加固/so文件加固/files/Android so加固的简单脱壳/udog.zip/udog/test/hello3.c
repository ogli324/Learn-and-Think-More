/* hello3.c */
/* #include <stdio.h> */

/* extern int g_ywb = 1210; */

/* extern void bar() { */
/* 	g_ywb &= 1993; */
/* } */
