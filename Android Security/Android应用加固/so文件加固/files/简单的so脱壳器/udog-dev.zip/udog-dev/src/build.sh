rm ./udog
make udog DEBUG=1