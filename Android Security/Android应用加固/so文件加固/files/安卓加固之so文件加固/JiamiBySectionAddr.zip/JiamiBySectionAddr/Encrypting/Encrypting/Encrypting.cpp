// Encrypting.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <stdio.h>
#include <iostream>
using namespace std;
#include <Windows.h>
#include "elf.h"

int _tmain(int argc, _TCHAR* argv[])
{

	char szSoPath[MAX_PATH] = "libJniTest.so";
	char szSection[] = ".mytext";
	
	char *shstr = NULL;
	char *content = NULL;
	

	int i;
	unsigned int base, length;
	unsigned short nblock;
	unsigned short nsize;
	unsigned char block_size = 16;

	char* szFileData = NULL;
	unsigned int ulLow;
	HANDLE hFile;
	ULONG ulHigh = 0;
	ULONG ulReturn = 0;

	//��ȡ�ļ����ڴ�
	hFile = CreateFileA(szSoPath,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if (hFile==INVALID_HANDLE_VALUE)
	{
		printf("�򿪵��ļ������ڣ�");
		return -1;
	}
	ulLow = GetFileSize(hFile,&ulHigh); 
	szFileData = new char[ulLow + 20];
	printf("Read File at 0x%x\r\n",szFileData);
	if (ReadFile(hFile,szFileData,ulLow,&ulReturn,NULL)==0)
	{
		CloseHandle(hFile);
		delete szFileData;
		return FALSE;
	}



	Elf32_Ehdr* ehdr = (Elf32_Ehdr*)(szFileData);
	Elf32_Shdr* shdrstr =  (Elf32_Shdr*)(szFileData + ehdr->e_shoff + sizeof(Elf32_Shdr) * ehdr->e_shstrndx); //�ַ�������������ƫ�Ƶ��ַ�����
	shstr = (char*)(szFileData + shdrstr->sh_offset);//ƫ�Ƶ��ַ�����
	Elf32_Shdr* Shdr = (Elf32_Shdr*)(szFileData + ehdr->e_shoff);


	for(i = 0; i < ehdr->e_shnum; i++){
		//�����ַ����������ƱȽ�
		if(strcmp(shstr + Shdr->sh_name, szSection) == 0){
			base = Shdr->sh_offset;
			length = Shdr->sh_size;
			printf("Find section %s at 0x%x the size is 0x%x\n", szSection,base,length);
			break;
		}
		Shdr++;
	}

	content= (char*)(szFileData + base);
	nblock = length / block_size;
	nsize = base / 4096 + (base % 4096 == 0 ? 0 : 1);
	printf("base = 0x%x, length = 0x%x\n", base, length);
	printf("nblock = %d, nsize = %d\n", nblock, nsize);

	//���ڵĵ�ַ�ʹ�Сд��
	ehdr->e_entry = (length << 16) + nsize;
	ehdr->e_shoff = base; //�ڵĵ�ַ
	
	printf("content is %x",content);
	//����
	for(i=0;i<length;i++){
		content[i] = ~content[i];
	}

	strcat(szSoPath,"_");
	HANDLE hFile1 = CreateFileA(szSoPath,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);

	if (hFile1==INVALID_HANDLE_VALUE)
	{
		printf("�����ļ�ʧ�ܣ�");
		return -1;
	}


	BOOL bRet = WriteFile(hFile1,szFileData,ulLow,&ulReturn,NULL);
	if(bRet)
	{
		printf("д��ɹ�!\r\n");
	}
	else
	{
		int a = GetLastError();
		printf("д��ʧ�ܣ�%d\r\n",a);
	}

_error:
	delete(szFileData);
	CloseHandle(hFile);


	return 0;
}


