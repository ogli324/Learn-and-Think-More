#include <jni.h>
#include <stdio.h>
//#include <assert.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <android/log.h>
#include <elf.h>
#include <sys/mman.h>

#define LOG_TAG "Jiami"
#define LOGD(fmt,args...) __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,fmt,##args)

typedef struct _funcInfo{
  Elf32_Addr st_value;
  Elf32_Word st_size;
}funcInfo;




JNIEXPORT jint JNICALL native_Add
(JNIEnv *env, jobject obj, jdouble num1, jdouble num2)
{
    return (jint)(num1 + num2 +3);
}


JNIEXPORT jint JNICALL native_Sub
        (JNIEnv *env, jobject obj, jdouble num1, jdouble num2)
{
    return (jint)(num1 - num2 +3);
}


JNIEXPORT jint JNICALL native_Mul
        (JNIEnv *env, jobject obj, jdouble num1, jdouble num2)
{
    return (jint)(num1 * num2 +3);
}

JNIEXPORT jint JNICALL native_Div
        (JNIEnv *env, jobject obj, jdouble num1, jdouble num2)
{
    if (num2 == 0) return 0;
    return (jint)(num1 / num2 +3);
}

//Java和JNI函数的绑定表
static JNINativeMethod gMethods[] = {
        {"Add", "(DD)I", (void *)native_Add},
        {"Sub", "(DD)I", (void *)native_Sub},
        {"Mul", "(DD)I", (void *)native_Mul},
        {"Div", "(DD)I", (void *)native_Div},
};




//注册native方法到java中
static int registerNativeMethods(JNIEnv* env, const char* className,
                                JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;
    clazz = (*env)->FindClass(env, className);
    if (clazz == NULL) {
        return JNI_FALSE;
    }
    if ((*env)->RegisterNatives(env, clazz, gMethods,numMethods) < 0){
        return JNI_FALSE;
    }

    return JNI_TRUE;
}


int register_ndk_load(JNIEnv *env)
{

    return registerNativeMethods(env, "com/example/caculate/MainActivity",
                                 gMethods,sizeof(gMethods) / sizeof(gMethods[0]));
                                 //NELEM(gMethods));
}


JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    JNIEnv* env = NULL;
    jint result = -1;

    if ((*vm)->GetEnv(vm, (void**) &env, JNI_VERSION_1_4) != JNI_OK) {
        return result;
    }

    register_ndk_load(env);

    // 返回jni的版本
    return JNI_VERSION_1_4;
}


//此属性在so被加载时，优于main执行，开始解密
void init_native_Add() __attribute__((constructor));
//void init_native_Div() __attribute__((constructor));
//void init_native_Mul() __attribute__((constructor));
//void init_native_Sub() __attribute__((constructor));
void init_native_Sub();
void init_native_Mul();
void init_native_Div();
unsigned long getLibAddr();

static char getTargetFuncInfo(unsigned long base, const char *funcName, funcInfo *info);


static unsigned elfhash(const char *_name)
{
    const unsigned char *name = (const unsigned char *) _name;
    unsigned h = 0, g;

    while(*name) {
        h = (h << 4) + *name++;
        g = h & 0xf0000000;
        h ^= g;
        h ^= g >> 24;
    }
    return h;
}

void init_native_Add(){

    const char target_fun[] = "native_Add";
    funcInfo info;
    int i;
    unsigned int npage, base = getLibAddr();

    LOGD("base addr is 0x%x",base);
    if(getTargetFuncInfo(base, target_fun, &info) == -1){
          LOGD("Find native_Add failed");
          return ;
    }

    npage = info.st_size / PAGE_SIZE + ((info.st_size % PAGE_SIZE == 0) ? 0 : 1);
    LOGD("npage =  0x%d", npage);
    LOGD("npage =  0x%d", PAGE_SIZE);

    if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC | PROT_WRITE) != 0){
          LOGD("mem privilege change failed");
     }

      for(i=0;i< info.st_size - 1; i++){
          char *addr = (char*)(base + info.st_value -1 + i);
          *addr = ~(*addr);
      }

      if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC) != 0){
          LOGD("mem privilege change failed");
      }
    init_native_Sub();
    init_native_Mul();
    init_native_Div();
}

void init_native_Sub(){

    const char target_fun[] = "native_Sub";
    funcInfo info;
    int i;
    unsigned int npage, base = getLibAddr();

    LOGD("base addr is 0x%x",base);
    if(getTargetFuncInfo(base, target_fun, &info) == -1){
          LOGD("Find native_Sub failed");
          return ;
    }

    npage = info.st_size / PAGE_SIZE + ((info.st_size % PAGE_SIZE == 0) ? 0 : 1);
    LOGD("npage =  0x%d", npage);
    LOGD("npage =  0x%d", PAGE_SIZE);

    if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC | PROT_WRITE) != 0){
          LOGD("mem privilege change failed");
     }

      for(i=0;i< info.st_size - 1; i++){
          char *addr = (char*)(base + info.st_value -1 + i);
          *addr = ~(*addr);
      }

      if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC) != 0){
          LOGD("mem privilege change failed");
      }
}

void init_native_Div(){

    const char target_fun[] = "native_Div";
    funcInfo info;
    int i;
    unsigned int npage, base = getLibAddr();

    LOGD("base addr is 0x%x",base);
    if(getTargetFuncInfo(base, target_fun, &info) == -1){
          LOGD("Find native_Div failed");
          return ;
    }

    npage = info.st_size / PAGE_SIZE + ((info.st_size % PAGE_SIZE == 0) ? 0 : 1);
    LOGD("npage =  0x%d", npage);
    LOGD("npage =  0x%d", PAGE_SIZE);

    if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC | PROT_WRITE) != 0){
          LOGD("mem privilege change failed");
     }

      for(i=0;i< info.st_size - 1; i++){
          char *addr = (char*)(base + info.st_value -1 + i);
          *addr = ~(*addr);
      }

      if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC) != 0){
          LOGD("mem privilege change failed");
      }
}

void init_native_Mul(){

    const char target_fun[] = "native_Mul";
    funcInfo info;
    int i;
    unsigned int npage, base = getLibAddr();

    LOGD("base addr is 0x%x",base);
    if(getTargetFuncInfo(base, target_fun, &info) == -1){
          LOGD("Find native_Mul failed");
          return ;
    }

    npage = info.st_size / PAGE_SIZE + ((info.st_size % PAGE_SIZE == 0) ? 0 : 1);
    LOGD("npage =  0x%d", npage);
    LOGD("npage =  0x%d", PAGE_SIZE);

    if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC | PROT_WRITE) != 0){
          LOGD("mem privilege change failed");
     }

      for(i=0;i< info.st_size - 1; i++){
          char *addr = (char*)(base + info.st_value -1 + i);
          *addr = ~(*addr);
      }

      if(mprotect((void *) ((base + info.st_value) / PAGE_SIZE * PAGE_SIZE), 4096*npage, PROT_READ | PROT_EXEC) != 0){
          LOGD("mem privilege change failed");
      }
}
//获取到SO文件加载到内存中的起始地址，只有找到起始地址才能够进行解密；
unsigned long getLibAddr(){
    unsigned long ret=0;
    char name[]="libJniTest.so";
    char buf[4096];
    char *temp;
    int pid;
    FILE *fp;
    pid=getpid();
    sprintf(buf,"/proc/%d/maps",pid);  //这个文件中保存了进程映射的模块信息  cap /proc/id/maps  查看
    fp=fopen(buf,"r");
    if(fp==NULL){
        LOGD("Error open maps file in progress %d",pid);
        puts("open failed");
        goto _error;
    }
    while (fgets(buf,sizeof(buf),fp)){
        if(strstr(buf,name)){
            temp = strtok(buf, "-");  //分割字符串，返回 - 之前的字符
            LOGD("Target so is %s\r\n",temp);
            ret = strtoul(temp, NULL, 16);  //获取地址
            LOGD("Target so address is %x",ret);
            break;
        }
    }
    _error:
    fclose(fp);
    return ret;
}


static char getTargetFuncInfo(unsigned long base, const char *funcName, funcInfo *info){
    char flag = -1, *dynstr;
    int i;
    Elf32_Ehdr *ehdr;
    Elf32_Phdr *phdr;
    Elf32_Off dyn_vaddr;
    Elf32_Word dyn_size, dyn_strsz;
    Elf32_Dyn *dyn;
    Elf32_Addr dyn_symtab, dyn_strtab, dyn_hash;
    Elf32_Sym *funSym;
    unsigned funHash, nbucket;
    unsigned *bucket, *chain;

    ehdr = (Elf32_Ehdr *)base;
    phdr = (Elf32_Phdr *)(base + ehdr->e_phoff);//视图模式
    LOGD("[+]phdr =  0x%p, size = 0x%x\n", phdr, ehdr->e_phnum);
    for (i = 0; i < ehdr->e_phnum; ++i) {
        LOGD("[+]phdr =  0x%p\n", phdr);
		//获得动态链接节
        if(phdr->p_type ==  PT_DYNAMIC){
            flag = 0;
            LOGD("Find .dynamic segment");
            break;
        }
        phdr ++;
    }
    if(flag)
        goto _error;
    dyn_vaddr = phdr->p_vaddr + base;
    dyn_size = phdr->p_filesz;
    LOGD("[+]dyn_vadd =  0x%x, dyn_size =  0x%x", dyn_vaddr, dyn_size);
    flag = 0;
    for (i = 0; i < dyn_size / sizeof(Elf32_Dyn); ++i) {
        dyn = (Elf32_Dyn *)(dyn_vaddr + i * sizeof(Elf32_Dyn));
		//符号表位置
        if(dyn->d_tag == DT_SYMTAB){
            dyn_symtab = (dyn->d_un).d_ptr;
            flag += 1;
            LOGD("[+]Find .dynsym section, addr = 0x%x\n", dyn_symtab);
        }
		//获得hash段
        if(dyn->d_tag == DT_HASH){
            dyn_hash = (dyn->d_un).d_ptr;
            flag += 2;
            LOGD("[+]Find .hash section, addr = 0x%x\n", dyn_hash);
        }
		//保存函数字符串的位置
        if(dyn->d_tag == DT_STRTAB){
            dyn_strtab = (dyn->d_un).d_ptr;
            flag += 4;
            LOGD("[+]Find .dynstr section, addr = 0x%x\n", dyn_strtab);
        }
		//字符串长度
        if(dyn->d_tag == DT_STRSZ){
            dyn_strsz = (dyn->d_un).d_val;
            flag += 8;
            LOGD("[+]Find strsz size = 0x%x\n", dyn_strsz);
        }
    }
    if((flag & 0x0f) != 0x0f){
        LOGD("Find needed .section failed\n");
        goto _error;
    }
    dyn_symtab += base;
    dyn_hash += base;
    dyn_strtab += base;
    dyn_strsz += base;

/*     nbucket                                                                 
 *-----------------
 *	   nchain
 *------------------
 *	  bucket[0]
 *       ...
 *   bucket[nbucket-1]
 * ------------------
 *     chain[0]
 *       ...
 *   chain[nchain-1]
 */
    funHash = elfhash(funcName);//获得函数名称经过hash运行后的值
    funSym = (Elf32_Sym *) dyn_symtab;
    dynstr = (char*) dyn_strtab;
    nbucket = *((int *) dyn_hash);//获得nbucket的值
    bucket = (int *)(dyn_hash + 8);//bucket链
    chain = (unsigned int *)(dyn_hash + 4 * (2 + nbucket));//越过bucket链，到达chain链

    flag = -1;
    LOGD("[+]hash = 0x%x, nbucket = 0x%x\n", funHash, nbucket);
	//bucket[X%nbucket]给出了一个索引y，该索引可用于符号表，也可用于chain表
    int mod = (funHash % nbucket);
    LOGD("[+]mod = %d\n", mod);
    LOGD("[+]i = 0x%d\n", bucket[mod]);
	//i = mod = bucket[funHash%nbucket]，通过遍历i = chain[i]表，找到funSym对应的符号表
    for(i = bucket[mod]; i != 0; i = chain[i]){
        LOGD("[+]Find index = %d\n", i);
        if(strcmp(dynstr + ((Elf32_Sym*)((char*)funSym + i* sizeof(Elf32_Sym)))->st_name, funcName) == 0){
            flag = 0;
            LOGD("[+]Find %s\n", funcName);
            break;
        }
    }
    if(flag) goto _error;
    info->st_value = ((Elf32_Sym*)((char*)funSym + i* sizeof(Elf32_Sym)))->st_value;//函数对应符号表中保存函数的地址
    info->st_size =((Elf32_Sym*)((char*)funSym + i* sizeof(Elf32_Sym)))->st_size;//函数符号表中保存函数的大小
    LOGD("[+]st_value = %d,st_size = %d",info->st_value,info->st_size);
    return 0;
_error:
    return -1;
}





